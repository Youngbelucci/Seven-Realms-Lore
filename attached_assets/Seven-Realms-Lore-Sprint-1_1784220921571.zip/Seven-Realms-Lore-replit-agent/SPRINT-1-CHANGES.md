# Sprint 1 — Combat Feel Upgrade

Implemented directly in the existing Canvas/TypeScript game engine:

- directional sword slash trails
- stronger critical-hit spark bursts
- camera look-ahead in the player's facing direction
- camera shake on swings, hits, multi-hits, and critical hits
- improved particle drag, gravity, glow, and streak rendering
- improved floating damage text with outlines and critical-hit scaling
- richer and longer-lasting blood decals

Modified files:

- `artifacts/seven-realms/src/game/types.ts`
- `artifacts/seven-realms/src/game/particles.ts`
- `artifacts/seven-realms/src/game/camera.ts`
- `artifacts/seven-realms/src/game/combat.ts`
- `artifacts/seven-realms/src/game/engine.ts`

## Import into Replit

Upload the complete ZIP and replace the project, or copy the five modified files into the same paths. Then run the normal Replit command.

The local environment used to prepare this update did not contain the workspace dependencies, so a full TypeScript build could not be completed here. The changes were written against the existing project interfaces and source structure.
